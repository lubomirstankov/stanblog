<div id="footer">
	<p>&copy; LightBlog (Powerfull fast blog CMS). All rights reserved. Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>