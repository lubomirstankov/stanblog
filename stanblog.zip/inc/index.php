<?php session_start();
echo $usern;
?>