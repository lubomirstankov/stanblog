<?php
// Session was started here
//
//
//   ---- Lubomir StankoV ---- 
// ▒█░░░ ░▀░ █▀▀▀ █░░█ ▀▀█▀▀ ▒█▀▀█ █░░ █▀▀█ █▀▀▀ 
// ▒█░░░ ▀█▀ █░▀█ █▀▀█ ░░█░░ ▒█▀▀▄ █░░ █░░█ █░▀█ 
// ▒█▄▄█ ▀▀▀ ▀▀▀▀ ▀░░▀ ░░▀░░ ▒█▄▄█ ▀▀▀ ▀▀▀▀ ▀▀▀▀ 
//
// Thx for using LightBlog 2017.. ;)
//
//
//
//
//
//
//Includes
require ("inc/database.php");
require ("inc/config.php");
// Message Variables
$error = "";
//
//
//
//Requirements
require ("assets/adm/login_requirements.php");
//
//
//
// Page HTML
include ("assets/adm/login.php");
?>