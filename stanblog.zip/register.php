<?php
// Session was started here
//
//
//   ---- Lubomir StankoV ---- 
// ▒█░░░ ░▀░ █▀▀▀ █░░█ ▀▀█▀▀ ▒█▀▀█ █░░ █▀▀█ █▀▀▀ 
// ▒█░░░ ▀█▀ █░▀█ █▀▀█ ░░█░░ ▒█▀▀▄ █░░ █░░█ █░▀█ 
// ▒█▄▄█ ▀▀▀ ▀▀▀▀ ▀░░▀ ░░▀░░ ▒█▄▄█ ▀▀▀ ▀▀▀▀ ▀▀▀▀ 
//
// Thx for using LightBlog 2017.. ;)
//
//
//
//
//
//
//Includes
require ("inc/database.php");
require ("inc/config.php");
// Message Variables
$msg = "";
// Requirements
require("assets/adm/register_requirements.php");
//
//
//
//Page html
include("assets/adm/register.php");
?>